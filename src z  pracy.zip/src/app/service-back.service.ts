import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable} from 'rxjs';


import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
@Injectable()
export class ServiceBackService {

  _url='http://localhost:3000/';

  constructor(private _HttpClient:HttpClient) { }

  get<T>(method:string): Observable<T[]>{
    return this._HttpClient
    .get<T[]>(this._url+method)
    .pipe((response) => {
      console.log('sssssssssss');
      return response;
    });
   }

   post<T>(method:string,arg:T):Observable<T>
   {
    return this._HttpClient.post<T>(this._url+method, arg);
   }
 
}
