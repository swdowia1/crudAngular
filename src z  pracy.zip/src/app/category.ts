// Category class to define this object's properties.
export class Category {
    id: number;
    name: string;
    description: string;
}