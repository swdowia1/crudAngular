import { Category } from "./category";

// Product class to define this object's properties.
export class Product {
    constructor(
        public id: number,
        public name: string,
        public price: number,
        public description: string,
        public category:Category
    ){}
}